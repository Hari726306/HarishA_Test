package com;

import java.util.Scanner;

public class Program2 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		System.out.println("enter the number: ");
		int a=scan.nextInt();

		int number=1;

		for(int i=1;i<=a;i++)
		{
			System.out.println(number);

			if(i<a)
			{
				System.out.println(", ");
			}

			number +=2;
		}

	}



}

